exports = {
  onDealUpdateCallback: function(args) {
    console.log(args)
  },
  getDealPdf: function(args) {
    console.log(args)
  }
};
